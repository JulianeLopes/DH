//
//  ViewController.swift
//  PickerView_desafio2
//
//  Created by Juliane Lopes on 06/05/22.
//  Copyright © 2022 DH. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var pickerView: UIPickerView!
    
    @IBOutlet weak var Label: UILabel!
    
    let arrHours = [0...24]
    let arrMins = [0...60]
    
    var horas: Int = 0
    var minutos: Int = 0
    var segundos: Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pickerView.delegate = self
        pickerView.dataSource = self
        
        Label.text = "0 horas, 0 min, 0 seg"
        
    }

    @IBAction func botaoIniciar(_ sender: Any) {
        
        Label.text = "\(horas) horas, \(minutos) min, \(segundos) seg"
        
    }
    
    
    @IBAction func botaoCancelar(_ sender: Any) {
        
         Label.text = "0 horas, 0 min, 0 seg"
    }
    
}


extension ViewController: UIPickerViewDelegate{
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch component{
        case 0:
            horas = row
        case 1:
            minutos = row
        default:
            segundos = row
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
       switch component {
           case 0:
            return "\(arrHours[row]) Hours"
           case 1:
            return "\(arrMins[row]) Min"
       default:
        return "\(arrMins[row]) Seg"
       }
    }
}

extension ViewController: UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 3
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
    switch component {
        case 1: return arrHours.count
        case 2: return arrMins.count
    default:
        return  arrMins.count
        }
    }
}

